package org.example.itog

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class ItogApplication

fun main(args: Array<String>) {
    runApplication<ItogApplication>(*args)
}
